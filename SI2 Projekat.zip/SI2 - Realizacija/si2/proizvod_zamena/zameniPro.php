<?php
 
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";



 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="zamena.php">Nazad na stranicu za zamenu proizvoda</a><br><br></center>';

 $TIP1 = mysqli_real_escape_string($conn, $_REQUEST['tip1']);
 $TIP2 = mysqli_real_escape_string($conn, $_REQUEST['tip2']);
 $naziv1 = mysqli_real_escape_string($conn, $_REQUEST['naziv1']);
 $naziv2 = mysqli_real_escape_string($conn, $_REQUEST['naziv2']);
 $racun = mysqli_real_escape_string($conn, $_REQUEST['racun']);
 $datum = date("Y-m-d");


$sql1 = "UPDATE $TIP1 SET Kolicina=Kolicina+1 WHERE Naziv='$naziv1'  ";
$sql2 = "UPDATE $TIP2 SET Kolicina=Kolicina-1 WHERE Naziv='$naziv2'  ";
$sql3 = "INSERT INTO zamena (Vracen, Uzet, IDRacuna, Datum) 
    VALUES ('$naziv1', '$naziv2', '$racun' , '$datum')";

rename ('../prodaja/Racuni/Racun_'. $racun.'.pdf', '../prodaja/Racuni/Racun_'. $racun.'_zamenjen.pdf');   
if ($conn->query($sql3) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }
 if ($conn->query($sql1) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

     if ($conn->query($sql2) === TRUE) {
     echo "<center>Uspesno ste zamenili proizvod!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();
?>