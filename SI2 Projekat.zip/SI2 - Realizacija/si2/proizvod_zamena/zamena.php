<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Zamena proizvoda</title>
    </head>

 <body>
     <center>
         <a href="/si2/cp/control_panel.php">Nazad na CP</a>
         
         <br><br><br>
         <p><form action="zameniPro.php" method="post" enctype="multipart/form-data">
                <label for="racun">Broj racuna:</label>
                <input type="text" name="racun" id="racun" required>
             </p>
             <br><br>
         
            <p>Unesite proizvod koji kupac zeli da vrati:</p> 
             <p>
      <label for="tip1">Tip proizvoda</label>
      <select id="tip1" name="tip1" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="hdd">Hard disk</option>
        <option value="dvdrom">DVD ROM</option>
        <option value="vga">Graficka kartica</option>
        <option value="hladnjaci">Hladnjak</option>
        <option value="kucista">Kuciste</option>
        <option value="maticne">Maticna ploca</option>
        <option value="napajanja">Napajanje</option>
        <option value="procesori">Procesor</option>
        <option value="ram">RAM memorija</option>
        <option value="ssd">SSD</option>
      </select>
     </p>

             <p>
             	<label for="Naziv">Naziv:</label>
                <input type="text" name="naziv1" id="naziv1" required>
             </p>
             <br><br><br>
              <p>Unesite proizvod koji kupac zeli da uzme:</p> 
<p>
      <label for="tip2">Tip proizvoda</label>
      <select id="tip2" name="tip2" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="hdd">Hard disk</option>
        <option value="dvdrom">DVD ROM</option>
        <option value="vga">Graficka kartica</option>
        <option value="hladnjaci">Hladnjak</option>
        <option value="kucista">Kuciste</option>
        <option value="maticne">Maticna ploca</option>
        <option value="napajanja">Napajanje</option>
        <option value="procesori">Procesor</option>
        <option value="ram">RAM memorija</option>
        <option value="ssd">SSD</option>
      </select>
     </p>

             <p>
                <label for="Naziv">Naziv:</label>
                <input type="text" name="naziv2" id="naziv2" required>
             </p>


             <input type="submit" value="Zameni proizvod">
            </form>
    </center>
 </body>
 </html>';