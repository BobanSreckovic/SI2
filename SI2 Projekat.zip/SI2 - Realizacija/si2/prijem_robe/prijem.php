<?php

echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Prijem robe</title>
</head>

<body>
 <center> 
   <form action="prijemPro.php" method="post">';

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "si2";

        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 

            echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
            echo '<br>';

         $sql = "SELECT * FROM naruceni_proizvodi WHERE Primljeno = 0";

         $result = $conn->query($sql);
 
         if ($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
            	 echo '<br>';
               echo "Sifra narudzbenice: " . $row["IDNARPRO"] . "&nbsp;  &nbsp;  &nbsp;";
               echo "Naziv: " . $row["Dobavljac"] . "&nbsp;  &nbsp;  &nbsp;";
               echo "Kolicina: " . $row["Kolicina"] . "&nbsp;  &nbsp;  &nbsp;";
               echo '<input type="radio" name="IDNARPRO" value="' . $row["IDNARPRO"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
               }
           } else {
               echo "Nema narucenih prozivoda od strane dobavljaca";
          }
echo'

     <br><br><br>
     <input type="submit" value="Primi robu">
   </form>
 </center>
</body>
</html>';

?>