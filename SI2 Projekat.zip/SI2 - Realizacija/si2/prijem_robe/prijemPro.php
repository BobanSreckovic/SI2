<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";



 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="prijem.php">Nazad na stranicu za prijem proizvoda</a><br><br></center>';

 $IDNARPRO = mysqli_real_escape_string($conn, $_REQUEST['IDNARPRO']);
 $Datum = date("Y-m-d");

 $sql = "SELECT IDNR,Kolicina,Dobavljac FROM naruceni_proizvodi WHERE IDNARPRO=$IDNARPRO AND Primljeno = 0";

$result = $conn->query($sql);
 
         if ($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
            	$x = $row["IDNR"];
            	$y = $row["Kolicina"];
            	$z = $row["Dobavljac"];
            }}

//echo $x;

 $sql1 = "SELECT * FROM narudzbina_radnik WHERE IDNR=$x";

 $result1 = $conn->query($sql1);
 
         if ($result1->num_rows > 0) { 
            while($row = $result1->fetch_assoc()) {
            	$tabela = $row["Tabela"];
            	$id = $row["id"];
            	$Naziv = $row["Naziv"];
            }}

//echo $tabela;
//echo $id;
//echo $Naziv;

$sql2 = "UPDATE $tabela SET Kolicina = Kolicina + $y WHERE Naziv = '$Naziv'";
if ($conn->query($sql2) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

$sql3 = "UPDATE naruceni_proizvodi SET Primljeno = 1 WHERE IDNARPRO = '$IDNARPRO'";

if ($conn->query($sql3) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

$sql4 = "INSERT INTO fakture (Ime, Dobavljac, Kolicina, Datum_Prijema) 
    VALUES ('$Naziv', '$z', '$y' , '$Datum')";

if ($conn->query($sql4) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }



 $conn->close();
?>