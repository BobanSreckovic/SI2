<?php
session_start();
$x="Admin";
if ($_SESSION["Permisija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Ukloni CPU</title>
</head>

<body>
 <center> 
   <form action="obrisiCPU.php" method="post">';

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "si2";

        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 

            echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
            echo '<br>';
            echo '<a href="ukloniPro.php">Nazad na stranicu za uklanjanje proizvoda</a>';
            echo '<br>';

         $sql = "SELECT IDCPU,Naziv FROM procesori";

         $result = $conn->query($sql);
 
         if ($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
            	 echo '<br>';
               echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
               echo '<input type="radio" name="IDCPU" value="' . $row["IDCPU"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
               }
           } else {
               echo "Nema proizvoda";
          }
echo'

     <br><br><br>
     <input type="submit" value="Obrisi CPU">
   </form>
 </center>
</body>
</html>';}
else{
  header('Location: index.php');
}
?>