<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";

$x="Admin";
if ($_SESSION["Permisija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="ukloniPro.php">Nazad na stranicu za uklanjanje proizvoda</a><br><br></center>';

 $IDCPU = mysqli_real_escape_string($conn, $_REQUEST['IDCPU']);

 $sql = "DELETE FROM procesori WHERE IDCPU=$IDCPU";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Procesor uspesno obrisano!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();}else{header('Location: index.php');}
?>