<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";

$x="Admin";
if ($_SESSION["Permisija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="ukloniPro.php">Nazad na stranicu za uklanjanje proizvoda</a><br><br></center>';

 $IDBOX = mysqli_real_escape_string($conn, $_REQUEST['IDBOX']);

 $sql = "DELETE FROM kucista WHERE IDBOX=$IDBOX";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Kuciste uspesno obrisano!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();}else{header('Location: index.php');}
?>