<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Promena prodajne cene usled promene nabavne cene - Kucista</title>
</head>

<body>
 <center> 
   <form action="cznRAM.php" method="post">';

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "si2";

        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 

            echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
            echo '<br>';
            echo '<a href="promenaCZN.php">Nazad na stranicu za promenu</a>';
            echo '<br>';

         $sql = "SELECT IDRAM,Naziv FROM ram";

         $result = $conn->query($sql);

 echo '<br><br><p>
      <label for="promena">Nova nabavna cena</label>
      <input type="text" name="promena" id="promena" required>
     </p>';
         if ($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
            	 echo '<br>';
               echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
               echo '<input type="radio" name="IDRAM" value="' . $row["IDRAM"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
               }
           } else {
               echo "Nema proizvoda";
          }
echo'

     <br><br><br>
     <input type="submit" value="Promeni">
   </form>
 </center>
</body>
</html>';

?>