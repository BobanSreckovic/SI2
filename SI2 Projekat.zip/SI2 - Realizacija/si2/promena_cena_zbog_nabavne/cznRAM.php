<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="promenaCZN.php">Nazad na stranicu za promenu prodajne cene usled promene nabavne cene</a><br><br></center>';

 $IDRAM = mysqli_real_escape_string($conn, $_REQUEST['IDRAM']);
 $Cena_nabavna = mysqli_real_escape_string($conn, $_REQUEST['promena']);
 $Cena_prodajna = $Cena_nabavna + ($Cena_nabavna * 0.2);


 $sql = "UPDATE ram SET Cena_prodajna = '$Cena_prodajna', Cena_nabavna = '$Cena_nabavna' WHERE IDRAM=$IDRAM";

 if ($conn->query($sql) === TRUE) {
     echo "<center>Uspesno promenjene cene!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();
?>