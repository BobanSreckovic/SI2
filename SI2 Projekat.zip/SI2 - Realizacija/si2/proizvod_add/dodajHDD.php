<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";
 
$x="Admin";
if ($_SESSION["Permisija"] == $x) {

 echo'<center><a href="dodajPro.php">Nazad na dodavanje novih proizvoda</a><br><br></center>';
     
 $conn = new mysqli($servername, $username, $password, $dbname);
 
 if($conn === false){
     die("ERROR: Could not connect. " . mysqli_connect_error());
     }


 $Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
 $Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $Cena_nabavna = mysqli_real_escape_string($conn, $_REQUEST['cena_nabavna']);
 $Tip = mysqli_real_escape_string($conn, $_REQUEST['tip']);
 $Povezivanje = mysqli_real_escape_string($conn, $_REQUEST['povezivanje']);
 $Kapacitet = mysqli_real_escape_string($conn, $_REQUEST['kapacitet']);
 $Format = mysqli_real_escape_string($conn, $_REQUEST['format']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);
 $Link = mysqli_real_escape_string($conn, $_REQUEST['link']);
 $Cena_prodajna = $Cena_nabavna + ($Cena_nabavna * 0.2);
 $Poruceno = 0;
  $Brojac = 0;
   $Kolicina_prodato = 0;
    $datum = date("Y-m-d");

 $sql = "INSERT INTO hdd (Naziv, Proizvodjac, Cena_nabavna, Cena_prodajna, Tip, Povezivanje, Kapacitet, Format, Kolicina, Poruceno, Link, Brojac, Kolicina_prodato, Datum) 
    VALUES ('$Naziv', '$Proizvodjac', '$Cena_nabavna' , '$Cena_prodajna', '$Tip', '$Povezivanje', '$Kapacitet', '$Format', '$Kolicina', '$Poruceno', '$Link', '$Brojac', '$Kolicina_prodato', '$datum')";

 if(mysqli_query($conn, $sql)){
        echo '<center>HDD uspesno dodat!</center>';
     } else{
         echo '<center>Lose ste uneli podatke"' . mysqli_error($conn).'</center>';
     }
 
 // OVO NIJE MOJE - GOTOV KOD ZA UPLOAD

 $target_dir = "jao/";
 $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
 $uploadOk = 1;
 $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            echo "<center>Fajl je slika - " . $check["mime"] . ".</center>";
            $uploadOk = 1;
        } else {
            echo "<center>Fajl nije slika.</center>";
            $uploadOk = 0;
        }
    }
    // Check if file already exists
    if (file_exists($target_file)) {
        echo "<center>Fajl postoji!.</center>";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 1000000) {
        echo "<center>Fajl je prevelik.</center>";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "<center>Samo JPG, JPEG, PNG & GIF ekstenzije fajla su dozvoljene.</center>";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "<center>Fajl nije uploadovan.</center>";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "<center>Fajl ". basename( $_FILES["fileToUpload"]["name"]). " je uploadovan.</center>";
            $pictureName = "jao/". basename( $_FILES["fileToUpload"]["name"]);

    $sql1 = "UPDATE hdd SET Slika='$pictureName' WHERE Naziv='$Naziv'";
    // Make Sure to tell MySQL which user you want to update which means setting the variable $myEmail and $myPassword accordingly

    if ($conn->query($sql1) === TRUE) {
        echo "<center>Uspesno dodavanje</center></center>";
    } else {
        echo "<center>Greska pri dodavanju: </center>" . $conn->error;
    }

        } else {
            echo "<center>Greska prilikom upload fajla.</center>";
        }
    }

 mysqli_close($conn);}else{header('Location: index.php');}
?>