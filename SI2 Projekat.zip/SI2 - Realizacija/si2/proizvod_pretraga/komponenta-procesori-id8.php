<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pretraga Procesora</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
         <a href="pretraga.php">Nazad na pretragu proizvoda</a></center>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>

<?php
$sql1 = "SELECT * FROM procesori ORDER BY Cena_prodajna ASC";
$result1 = $conn->query($sql1)->fetch_object();
?> 


 <center>
 <div class="pretraga">
   <form action="izborCpu.php">

     <p>
      <label for="nazivKomp">Naziv</label><br>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label><br>
      <select id="proizvodjac" name="proizvodjac" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="INTEL">INTEL</option>
        <option value="AMD">AMD</option>
      </select>
     </p>

      <label for="cena">Cena</label><br>
      <select id="cena" name="cena" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1"> <500 </option>
        <option value="2"> 500-1000 </option>
        <option value="3"> 1000-2000 </option>
        <option value="4"> 2000-5000 </option>
        <option value="5"> 5000-10000 </option>
        <option value="6"> 10000-25000 </option>
        <option value="7"> 25000-50000 </option>
        <option value="8"> 50000-100000 </option>
        <option value="9"> >100000 </option>
      </select>
     </p>

     <p>
      <label for="slot">Slot</label><br>
      <select id="slot" name="slot" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="FM2+">FM2+</option>
        <option value="AM3+">AM3+</option>
        <option value="AM4">AM4</option>
        <option value="TR4">TR4</option>
        <option value="1150">1150</option>
        <option value="1151">1151</option>
        <option value="2066">2066</option>
      </select>
     </p>
    
     <p>
      <label for="takt">Takt</label><br>
      <select id="takt" name="takt" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="3.0GHz"> 3.0GHz </option>
        <option value="3.1GHz"> 3.1GHz </option>
        <option value="3.2GHz"> 3.2GHz </option>
        <option value="3.3GHz"> 3.3GHz </option>
        <option value="3.5GHz"> 3.5GHz </option>
        <option value="3.6GHz"> 3.6GHz </option>
        <option value="3.7GHz"> 3.7GHz </option>
        <option value="3.8GHz"> 3.8GHz </option>
        <option value="4.0GHz"> 4.0GHz </option>
        <option value="4.2GHz"> 4.2GHz </option>
      </select>
     </p>
        
     <br>

     <p>
       <input type="submit" value="Pretraga"></p>
       <p>
       <input type="reset"></p>
  </form>
  </div>

 <br>

 <div class="prikazKomponenti"><p>
  
 <?php 

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
    	echo '<img img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Proizvodjac: " . "<b>". $row["Proizvodjac"] . "</b>"."<br>";
      echo "Slot: " . "<b>". $row["Slot"] ."</b>". "<br>";
      echo "Takt: " . "<b>". $row["Takt"] ."</b>". "<br>";
echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
      }}
 ?>   
 </p></div>

 
    
</body>
</html> 