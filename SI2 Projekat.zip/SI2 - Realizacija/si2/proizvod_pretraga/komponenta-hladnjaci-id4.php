<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pretraga Hladnjaka</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
         <a href="pretraga.php">Nazad na pretragu proizvoda</a></center>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>

<?php
$sql1 = "SELECT * FROM hladnjaci ORDER BY Cena_prodajna ASC";
$result1 = $conn->query($sql1)->fetch_object();
?> 


 <center>
 <div class="pretraga">
   <form action="izborCool.php">

     <p>
      <label for="nazivKomp">Naziv</label><br>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label><br>
      <select id="proizvodjac" name="proizvodjac" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="COOLER MASTER">COOLER MASTER</option>
        <option value="ARCTIC">ARCTIC</option>
        <option value="THERMALTAKE">THERMALTAKE</option>
      </select>
     </p>

      <label for="cena">Cena</label><br>
      <select id="cena" name="cena" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1"> <500 </option>
        <option value="2"> 500-1000 </option>
        <option value="3"> 1000-2000 </option>
        <option value="4"> 2000-5000 </option>
        <option value="5"> 5000-10000 </option>
        <option value="6"> 10000-25000 </option>
        <option value="7"> 25000-50000 </option>
        <option value="8"> 50000-100000 </option>
        <option value="9"> >100000 </option>
      </select>
     </p>

     <p>
      <label for="kompatibilnost">Kompatibilnost</label><br>
      <select id="kompatibilnost" name="kompatibilnost" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="775/">Intel 775</option>
        <option value="1150/">Intel 1150</option>
        <option value="1151/">Intel 1151</option>
        <option value="1155/">Intel 1155</option>
        <option value="1156/">Intel 1156</option>
        <option value="1366/">Intel 1366</option>
        <option value="754/">Intel 754</option>
        <option value="939/">Intel 939</option>
        <option value="2011/">Intel 2011</option>
        <option value="AM2/">AMD AM2</option>
        <option value="AM2+/">AMD AM2+</option>
        <option value="AM3/">AMD AM3</option>
        <option value="AM3+/">AMD AM3+</option>
        <option value="AM4/">AMD AM4</option>
        <option value="FM1/">AMD FM1</option>
        <option value="FM2/">AMD FM2</option>
      </select>
     </p>
     <br>

     <p>
       <input type="submit" value="Pretraga"></p>
       <p>
       <input type="reset"></p>
  </form>
  </div>

 <br>

 <div class="prikazKomponenti"><p>
  
 <?php 

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
    	echo '<img img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Proizvodjac: " . "<b>". $row["Proizvodjac"] . "</b>"."<br>";
      echo "Kompatibilnost: " . "<b>". $row["Kompatibilnost"] ."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
      }}
 ?>   
 </p></div>

 
    
</body>
</html> 