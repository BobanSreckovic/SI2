<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Pretraga Proizvod</title>
  <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body><br><br><br>
    <center><h1>PRETRAGA PROIZVODA</h1></center>
<br><br><br>
<center><table id="izbor1">
   <tr>
    <td>&nbsp&nbsp<a href="/si2/proizvod_pretraga/komponenta-hdd-id1.php"><img src="/si2/slike/slikeizbor/hddnova.png" style="width:150px;height:150px;"><br><center><b>Hard diskovi</b></center></a></td>

    <td>&nbsp&nbsp&nbsp<a href="/si2/proizvod_pretraga/komponenta-dvdrom-id2.php"><img src="/si2/slike/slikeizbor/romOtvoren.png" style="width:150px;height:150px;"><br><center><b>DVD ROM</b></center></a></td>

    <td><a href="/si2/proizvod_pretraga/komponenta-grafickekarte-id3.php"><img src="/si2/slike/slikeizbor/graficka.png" style="width:150px;height:150px;"><br><center><b>Graficke kartice</b></center></a></td>

    <td><a href="/si2/proizvod_pretraga/komponenta-hladnjaci-id4.php"><img src="/si2/slike/slikeizbor/hladnjak.png" style="width:150px;height:150px;"><br><center><b>Hladnjaci</b></center></a></td>

    <td><a href="/si2/proizvod_pretraga/komponenta-kucista-id5.php"><img src="/si2/slike/slikeizbor/kuciste.png" style="width:150px;height:150px;"><br><center><b>Kucista</b></center></a></td>
  </tr>
  </table></center> 

  <br><br>

  <center> <table id="izbor2">
   <tr>
    <td>&nbsp<a href="/si2/proizvod_pretraga/komponenta-maticneploce-id6.php"><img src="/si2/slike/slikeizbor/maticna.png" style="width:150px;height:150px;"><br><center><b>Maticne ploce</b></center></a></td>

    <td>&nbsp&nbsp<a href="/si2/proizvod_pretraga/komponenta-napajanja-id7.php"><img src="/si2/slike/slikeizbor/napajanje.png" style="width:150px;height:150px;"><br><center><b>Napajanja</b></center></a></td>

    <td>&nbsp<a href="/si2/proizvod_pretraga/komponenta-procesori-id8.php"><img src="/si2/slike/slikeizbor/procesor.png" style="width:150px;height:150px;"><br><center><b>Procesori</b></center></a></td>

    <td>&nbsp<a href="/si2/proizvod_pretraga/komponenta-rammemorije-id9.php"><img src="/si2/slike/slikeizbor/ram.png" style="width:150px;height:150px;"><br><center><b>RAM memorije</b></center></a></td>

    <td>&nbsp<a href="/si2/proizvod_pretraga/komponenta-ssd-id10.php"><img src="/si2/slike/slikeizbor/ssdnovi.png" style="width:150px;height:150px;"><br><center><b>SSD</b></center></a></td>
  </tr>
 </table></center> 


<br><br>
      <center><div id="jao1">  <a href="/si2/cp/control_panel.php">Nazad na CP</a></div></center>
    
      
</body>
</html>';

?>