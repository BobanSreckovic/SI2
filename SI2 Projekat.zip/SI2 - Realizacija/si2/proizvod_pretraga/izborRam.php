<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn === false){
  die("ERROR: Could not connect. " . mysqli_connect_error());
 }

$x="";
$Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
$Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
$Cena_prodajna = mysqli_real_escape_string($conn, $_REQUEST['cena']);
$Tip = mysqli_real_escape_string($conn, $_REQUEST['tip']);
$Takt = mysqli_real_escape_string($conn, $_REQUEST['takt']);
$Latencija = mysqli_real_escape_string($conn, $_REQUEST['latencija']);
$Kapacitet = mysqli_real_escape_string($conn, $_REQUEST['kapacitet']);

if ($Cena_prodajna == 1) {
	$x="Cena_prodajna BETWEEN 0 AND 500";
 }elseif ($Cena_prodajna == 2) {
	$x="Cena_prodajna BETWEEN 500 AND 1000";
 }elseif ($Cena_prodajna == 3) {
	$x="Cena_prodajna BETWEEN 1000 AND 2000";
 }elseif ($Cena_prodajna == 4) {
	$x="Cena_prodajna BETWEEN 2000 AND 5000";
 }elseif ($Cena_prodajna == 5) {
	$x="Cena_prodajna BETWEEN 5000 AND 10000";
 }elseif ($Cena_prodajna == 6) {
	$x="Cena_prodajna BETWEEN 10000 AND 25000";
 }elseif ($Cena_prodajna == 7) {
 	$x="Cena_prodajna BETWEEN 25000 AND 50000";
 }elseif ($Cena_prodajna == 8) {
	$x="Cena_prodajna BETWEEN 50000 AND 100000";
 }else{
	$x="Cena_prodajna BETWEEN 100000 AND 100000000";
}


$sql = "SELECT * FROM ram WHERE Proizvodjac='$Proizvodjac' AND Tip='$Tip' AND BrzinaRada='$Takt' 
AND Kapacitet='$Kapacitet' AND Latencija='$Latencija' AND Naziv LIKE '%$Naziv%' AND $x ORDER BY Cena_prodajna ASC";

$result = $conn->query($sql)->fetch_object();
$result = $conn->query($sql);

echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pretraga RAM</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
         <a href="pretraga.php">Nazad na pretragu proizvoda</a>
  <div class="pretraga">
    <form action="izborRam.php">
     <p>
      <label for="nazivKomp">Naziv</label><br>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label><br>
      <select id="proizvodjac" name="proizvodjac" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="KINGSTON">KINGSTON</option>
        <option value="CORSAIR">CORSAIR</option>
        <option value="PATRIOT">PATRIOT</option>
      </select>
     </p>
<p>
      <label for="cena">Cena</label><br>
      <select id="cena" name="cena" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1"> <500 </option>
        <option value="2"> 500-1000 </option>
        <option value="3"> 1000-2000 </option>
        <option value="4"> 2000-5000 </option>
        <option value="5"> 5000-10000 </option>
        <option value="6"> 10000-25000 </option>
        <option value="7"> 25000-50000 </option>
        <option value="8"> 50000-100000 </option>
        <option value="9"> >100000 </option>
      </select>
     </p>

     <p>
      <label for="tip">Tip</label><br>
      <select id="tip" name="tip" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="DDR2">DDR2</option>
        <option value="DDR3">DDR3</option>
        <option value="DDR4">DDR4</option>
      </select>
     </p>
    
     <p>
      <label for="takt">Takt</label><br>
      <select id="takt" name="takt" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="667MHz"> 667MHz </option>
        <option value="1333MHz"> 1333MHz </option>
        <option value="1600MHz"> 1600MHz </option>
        <option value="1866MHz"> 1866MHz </option>
        <option value="2400MHz"> 2400MHz </option>
        <option value="3000MHz"> 3000MHz </option>
      </select>
     </p>
        
   <p>
      <label for="latencija">Latencija</label><br>
      <select id="latencija" name="latencija" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="667MHz"> CL5 </option>
        <option value="1333MHz"> CL9 </option>
        <option value="1600MHz"> CL10 </option>
        <option value="1866MHz"> CL15 </option>
        <option value="2400MHz"> CL16 </option>
      </select>
     </p>

     <p>
      <label for="kapacitet">Kapacitet</label><br>
      <select id="kapacitet" name="kapacitet" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1GB"> 1GB </option>
        <option value="2GB"> 2GB </option>
        <option value="4GB"> 4GB </option>
        <option value="8GB"> 8GB </option>
        <option value="16GB"> 16GB </option>
      </select>
     </p><br>

     <p>
      <input type="submit" value="Pretraga"></p>
      <p>
      <input type="reset"></p>
    </form>



 <br>
 </div><br>
 <div class="prikazKomponenti"><p>';


if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo '<center><table><tr>';
    echo '<br>';
    echo '<td>';
    echo '<img img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'"/><br>';
    echo "Naziv: <b>" . $row["Naziv"]. "</b><br>";
    echo "Proizvodjac:<b> " . $row["Proizvodjac"] . "</b><br>";
    echo "Tip:<b> " . $row["Tip"] . "</b><br>";
    echo "Takt:<b> " . $row["BrzinaRada"] . "</b><br>";
    echo "Kapacitet:<b> " . $row["Kapacitet"] . "</b><br>";
    echo "Latencija: <b>" . $row["Latencija"] . "</b><br>";
     echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
    echo "Cena: <b>" . $row["Cena_prodajna"]. " din" . "</b><br></center></td>";
    echo '</center></table></tr>';
    if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }
   
  } else {
      echo "Zao nam je, trenutno nemamo takve uredjaje u ponudi, 
      ukoliko zelite da saznate da li je trazeni uredjaj dobavljiv -
      kontaktirajte nas putem poruke klikom na Kontakt. 
      "; 
    }
    echo '</p></div>';

mysqli_close($conn);
?>


    
</body>
</html> 