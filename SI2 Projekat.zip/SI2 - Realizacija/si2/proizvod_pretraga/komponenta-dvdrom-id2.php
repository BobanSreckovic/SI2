<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pretraga DVD ROM</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
         <a href="pretraga.php">Nazad na pretragu proizvoda</a></center>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>
<?php
$sql1 = "SELECT * FROM dvdrom ORDER BY Cena_prodajna ASC";
$result1 = $conn->query($sql1)->fetch_object();
?> 
<center>
 <div class="pretraga">
   <form action="izborDvd.php">

     <p>
      <label for="nazivKomp">Naziv</label><br>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label><br>
      <select id="proizvodjac" name="proizvodjac" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="LG">LG</option>
        <option value="ASUS">ASUS</option>
        <option value="TRANSCEND">TRANSCEND</option>
      </select>
     </p>

      <label for="cena">Cena</label><br>
      <select id="cena" name="cena" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1"> <500 </option>
        <option value="2"> 500-1000 </option>
        <option value="3"> 1000-2000 </option>
        <option value="4"> 2000-5000 </option>
        <option value="5"> 5000-10000 </option>
        <option value="6"> 10000-25000 </option>
        <option value="7"> 25000-50000 </option>
        <option value="8"> 50000-100000 </option>
        <option value="9"> >100000 </option>
      </select>
     </p>

     <p>
      <label for="tip">Tip</label><br>
      <select id="tip" name="tip" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="Interni">Interni</option>
        <option value="Eksterni">Eksterni</option>
      </select>
     </p>
     <br>

     <p>
       <input type="submit" value="Pretraga"></p>
       <p>
       <input type="reset"></p>
  </form>
  </div>
</center>
 <br>

 <div class="prikazKomponenti"><p>
 <?php 

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Proizvodjac: " . "<b>". $row["Proizvodjac"] . "</b>"."<br>";
      echo "Tip: " . "<b>". $row["Tip"] ."</b>". "<br>";
       echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
      }}
 ?>   
 </p></div>

 

 </div></center>
    
</body>
</html> 