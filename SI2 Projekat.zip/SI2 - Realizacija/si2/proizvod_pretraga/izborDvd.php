<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn === false){
  die("ERROR: Could not connect. " . mysqli_connect_error());
 }

$x="";
$Naziv = mysqli_real_escape_string($conn, $_REQUEST['naziv']);
$Proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
$Cena_prodajna = mysqli_real_escape_string($conn, $_REQUEST['cena']);
$Tip = mysqli_real_escape_string($conn, $_REQUEST['tip']);


if ($Cena_prodajna == 1) {
	$x="Cena_prodajna BETWEEN 0 AND 500";
 }elseif ($Cena_prodajna == 2) {
	$x="Cena_prodajna BETWEEN 500 AND 1000";
 }elseif ($Cena_prodajna == 3) {
	$x="Cena_prodajna BETWEEN 1000 AND 2000";
 }elseif ($Cena_prodajna == 4) {
	$x="Cena_prodajna BETWEEN 2000 AND 5000";
 }elseif ($Cena_prodajna == 5) {
	$x="Cena_prodajna BETWEEN 5000 AND 10000";
 }elseif ($Cena_prodajna == 6) {
	$x="Cena_prodajna BETWEEN 10000 AND 25000";
 }elseif ($Cena_prodajna == 7) {
 	$x="Cena_prodajna BETWEEN 25000 AND 50000";
 }elseif ($Cena_prodajna == 8) {
	$x="Cena_prodajna BETWEEN 50000 AND 100000";
 }else{
	$x="Cena_prodajna BETWEEN 100000 AND 100000000";
}


$sql = "SELECT * FROM dvdrom WHERE Proizvodjac='$Proizvodjac' AND Tip='$Tip' AND Naziv LIKE '%$Naziv%' AND $x ORDER BY Cena_prodajna ASC";

$result = $conn->query($sql)->fetch_object();
$result = $conn->query($sql);

echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pretraga DVD ROM</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
         <a href="pretraga.php">Nazad na pretragu proizvoda</a>
  <br>
  <div class="pretraga">
    <form action="izborDvd.php">
     <p>
      <label for="nazivKomp">Naziv</label><br>
      <input type="text" name="naziv" id="naziv">
     </p>

     <p>
      <label for="proizvodjac">Proizvodjac</label><br>
      <select id="proizvodjac" name="proizvodjac" required>
       <option selected disabled hidden>&nbsp;</option>
       <option value="LG">LG</option>
       <option value="ASUS">ASUS</option>
       <option value="TRANSCEND">TRANSCEND</option>
      </select>
     </p>

     <p>
      <label for="cena">Cena</label><br>
      <select id="cena" name="cena" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="1"> <500 </option>
        <option value="2"> 500-1000 </option>
        <option value="3"> 1000-2000 </option>
        <option value="4"> 2000-5000 </option>
        <option value="5"> 5000-10000 </option>
        <option value="6"> 10000-25000 </option>
        <option value="7"> 25000-50000 </option>
        <option value="8"> 50000-100000 </option>
        <option value="9"> >100000 </option>
      </select>
     </p>

     <p>
      <label for="tip">Tip</label><br>
      <select id="tip" name="tip" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="Interni">Interni</option>
        <option value="Eksterni">Eksterni</option>
      </select>
     </p>

     <p>
      <input type="submit" value="Pretraga"></p>
      <p>
      <input type="reset"></p>
    </form>

     

 <br>
 </div><br>
 <div class="prikazKomponenti"><p>';


if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo '<center><table><tr>';
    echo '<br>';
    echo '<td>';
    echo '<img img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'"/><br>';
    echo "Naziv:<b>  " . $row["Naziv"]. "</b><br>";
    echo "Proizvodjac:<b>  " . $row["Proizvodjac"] . "</b><br>";
    echo "Tip:<b>  " . $row["Tip"] . "</b><br>";
     echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
    echo "Cena:<b> " . $row["Cena_prodajna"]. " din" . "</b><br></center></td>";
    echo '</center></table></tr>';
    if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   
   }
  } else {
      echo "Zao nam je, trenutno nemamo takve uredjaje u ponudi, 
      ukoliko zelite da saznate da li je trazeni uredjaj dobavljiv -
      kontaktirajte nas putem poruke klikom na Kontakt. 
      "; 
    }
    echo '</p></div></center>';

mysqli_close($conn);
?>


    
</body>
</html> 