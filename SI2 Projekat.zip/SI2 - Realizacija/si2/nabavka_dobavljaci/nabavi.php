<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Nabavka prozivoda od dobavljaca</title>
</head>

<body>
 <center> 
   <form action="nabaviPro.php" method="post">';

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "si2";

        $conn = new mysqli($servername, $username, $password, $dbname);
        
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 

            echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
            echo '<br><br>
            Izaberite dobavljaca, kao i kolicinu koju zelite da porucite.<br> Potom odaberite proizvod koji porucujete - ponudjeni su proizvodi koji su prethodno poruceni od strane radnika posto ih nije bilo na stanju prilikom pokusaja prodaje<br><br>';
            echo '<p>
      <label for="dob">Izaberite dobavljaca</label>
      <select id="dob" name="dob" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="emmi@mail.rs">Emmi</option>
        <option value="gigatron@mail.rs">Gigratron</option>
        <option value="winwin@mail.rs">WinWin</option>
        <option value="comtrade@mail.rs">ComTrade</option>
        <option value="tehnomanija@mail.rs">Tehnomanija</option>
      </select>
     </p>
     <p>
             	<label for="kolicina">Kolicina:</label>
                <input type="text" name="kolicina" id="kolicina" required>
             </p>';
         $sql = "SELECT IDNR,Naziv FROM narudzbina_radnik WHERE Naruceno = 0";

         $result = $conn->query($sql);
 
         if ($result->num_rows > 0) { 
            while($row = $result->fetch_assoc()) {
            	 echo '<br>';
               echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
               echo '<input type="radio" name="IDNR" value="' . $row["IDNR"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
               }
           } else {
               echo "Nema proizvoda koji su poruceni od strane radnika.";
          }
echo'

     <br><br><br>
     <input type="submit" value="Naruci">
   </form>
 </center>
</body>
</html>';
?>