<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";



 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="nabavi.php">Nazad na stranicu za nabavku proizvoda</a><br><br></center>';

 $IDNR = mysqli_real_escape_string($conn, $_REQUEST['IDNR']);
 $DOB = mysqli_real_escape_string($conn, $_REQUEST['dob']);
 $Kolicina = mysqli_real_escape_string($conn, $_REQUEST['kolicina']);
 $Primljeno = 0;


$sql1 = "UPDATE narudzbina_radnik SET Naruceno = 1 WHERE IDNR='$IDNR'";
$sql2 = "INSERT INTO naruceni_proizvodi (IDNR, Dobavljac, Kolicina, Primljeno) 
    VALUES ('$IDNR', '$DOB', '$Kolicina', '$Primljeno')";
   

 if ($conn->query($sql1) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

     if ($conn->query($sql2) === TRUE) {
     echo "<center>Uspesno ste narucili proizvod!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 $conn->close();
?>