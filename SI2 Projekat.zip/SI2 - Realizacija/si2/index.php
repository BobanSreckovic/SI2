<?php 
session_start();
$_SESSION["Permisija"] = "korisnik";
header('Location: //localhost/si2/login/login.php');
?>