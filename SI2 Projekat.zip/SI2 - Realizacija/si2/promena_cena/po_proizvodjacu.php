<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Promena cene proizvoda</title>
    </head>

 <body>
     <center>
         <a href="/si2/cp/control_panel.php">Nazad na CP</a>
<br>
<a href="/si2/promena_cena/izmeniCenuPro.php">Nazad na izmenu cena</a>

         <br><br><br>
         <form action="promeniCenuProizvodjac.php" method="post" enctype="multipart/form-data">
            <p>Izaberite vrstu proizvoda kome menjate cenu:</p> 
             <p>
      <label for="proizvodjac">Proizvodjac proizvoda</label>
      <select id="proizvodjac" name="proizvodjac" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="LG">LG</option>
        <option value="ASUS">ASUS</option>
        <option value="TRANSCEND">TRANSCEND</option>
        <option value="Seagate">Seagate</option>
        <option value="Toshiba">Toshiba</option>
        <option value="WD">WD</option>
        <option value="ARCTIC">ARCTIC</option>
        <option value="COOLER MASTER">COOLER MASTER</option>
        <option value="THERMALTAKE">THERMALTAKE</option>
        <option value="CORSAIR">CORSAIR</option>
<option value="MSI">MSI</option>
<option value="RAIDMAX">RAIDMAX</option>
<option value="LC POWER">LC POWER</option>
<option value="GIGABYTE">GIGABYTE</option>
<option value="ASRock">ASRock</option>
<option value="INTEL">INTEL</option>
<option value="AMD">AMD</option>
<option value="PATRIOT">PATRIOT</option>
<option value="KINGSTON">KINGSTON</option>
<option value="CRUCIAL">CRUCIAL</option>
<option value="SAMSUNG">SAMSUNG</option>
<option value="ZOTAC">ZOTAC</option>
<option value="XFX">XFX</option>
<option value="POWERCOLOR">POWERCOLOR</option>
<option value="Ostali">Ostali</option>





      </select>
     </p>

             <p>
                <label for="Popust">Unesite zeljeni popust:</label>
                <input type="text" name="popust" id="popust" required>
             </p>
         
         <input type="submit" value="Promeni cene">
     </form>
    </center>
 </body>
 </html>