<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Promena cene proizvoda</title>
    </head>

 <body>
     <center>
         <a href="/si2/cp/control_panel.php">Nazad na CP</a>
<br>
<a href="/si2/promena_cena/izmeniCenuPro.php">Nazad na izmenu cena</a>

         <br><br><br>
         <form action="promeniCenuVrsta.php" method="post" enctype="multipart/form-data">
            <p>Izaberite vrstu proizvoda kome menjate cenu:</p> 
             <p>
      <label for="tip">Tip proizvoda</label>
      <select id="tip" name="tip" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="hdd">Hard disk</option>
        <option value="dvdrom">DVD ROM</option>
        <option value="vga">Graficka kartica</option>
        <option value="hladnjaci">Hladnjak</option>
        <option value="kucista">Kuciste</option>
        <option value="maticne">Maticna ploca</option>
        <option value="napajanja">Napajanje</option>
        <option value="procesori">Procesor</option>
        <option value="ram">RAM memorija</option>
        <option value="ssd">SSD</option>
      </select>
     </p>

             <p>
                <label for="Popust">Unesite zeljeni popust:</label>
                <input type="text" name="popust" id="popust" required>
             </p>
         
         <input type="submit" value="Promeni cene">
     </form>
    </center>
 </body>
 </html>