<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Promena cene proizvoda</title>
    </head>

 <body>
     <center>
         <a href="/si2/cp/control_panel.php">Nazad na CP</a>

<br><br><br>
<p>Izaberite nacin promene cene:</p> 
         <a href="po_proizvodjacu.php">Po proizvodjacu proizvoda</a>
<br><br><br>
         <a href="po_vrsti.php">Po vrsti proizvoda</a>
         
         
    </center>
 </body>
 </html>