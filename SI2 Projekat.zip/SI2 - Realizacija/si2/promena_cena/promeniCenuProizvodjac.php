<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";

$x="Admin";
if ($_SESSION["Permisija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="/si2/cp/control_panel.php">Nazad na CP</a><br><br></center>';
  echo'<center><a href="/si2/promena_cena/izmeniCenuPro.php">Nazad na izmenu cena</a><br><br></center>';

 $proizvodjac = mysqli_real_escape_string($conn, $_REQUEST['proizvodjac']);
 $popust = mysqli_real_escape_string($conn, $_REQUEST['popust']);




$sql1 = "UPDATE dvdrom SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql2 = "UPDATE hdd SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql3 = "UPDATE hladnjaci SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql4 = "UPDATE kucista SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql5 = "UPDATE maticne SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql6 = "UPDATE napajanja SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql7 = "UPDATE procesori SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql8 = "UPDATE ram SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql9 = "UPDATE ssd SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";
$sql10 = "UPDATE vga SET Cena_prodajna=Cena_prodajna+(Cena_prodajna*$popust/100) WHERE Proizvodjac='$proizvodjac'";

 if ($conn->query($sql1) === TRUE) {
     echo "<center>Uspesno ste promenili cene!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }

 if ($conn->query($sql2) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql3) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql4) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql5) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql6) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql7) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql8) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql9) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }

      if ($conn->query($sql10) === TRUE) {
     echo "<center></center>";
     } else {
          echo "<center></center>" . $conn->error;
     }


 $conn->close();}else{header('Location: index.php');}
?>