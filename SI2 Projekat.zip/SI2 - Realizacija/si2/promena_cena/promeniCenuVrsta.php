<?php
 session_start();
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";

$x="Admin";
if ($_SESSION["Permisija"] == $x) {


 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="/si2/cp/control_panel.php">Nazad na CP</a><br><br></center>';
  echo'<center><a href="/si2/promena_cena/izmeniCenuPro.php">Nazad na izmenu cena</a><br><br></center>';

 $TIP = mysqli_real_escape_string($conn, $_REQUEST['tip']);
 $popust = mysqli_real_escape_string($conn, $_REQUEST['popust']);




$sql1 = "UPDATE $TIP SET Cena_prodajna=Cena_prodajna-(Cena_prodajna*$popust/100)";

 if ($conn->query($sql1) === TRUE) {
     echo "<center>Uspesno ste promenili cene!</center>";
     } else {
          echo "<center>Lose ste uneli podatke</center>" . $conn->error;
     }


 $conn->close();}else{header('Location: index.php');}
?>