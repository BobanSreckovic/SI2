<?php
session_start();
$x="Admin";
if ($_SESSION["Permisija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni Maticnu</title>
</head>

<body>
     <center> 
       <form action="izmeniMB.php" method="post" enctype="multipart/form-data">';

              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "si2";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'


 <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv" required>
     </p>

      <p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac" required>
     </p>

      <p>
             <label for="cena_nabavna">Nabavna cena</label>
             <input type="text" name="cena_nabavna" id="cena_nabavna" required>
           </p>

           <p>
             <label for="cena_prodajna">Prodajna cena</label>
             <input type="text" name="cena_prodajna" id="cena_prodajna" required>
           </p>


     <p>
      <label for="format">Format</label>
      <select id="format" name="format" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="Mini ITX">Mini ITX</option>
        <option value="Micro ATX">Micro ATX</option>
        <option value="ATX">ATX</option>
      </select>
     </p>

      <p>
             <label for="slot">Slot</label>
             <input type="text" name="slot" id="slot" required>
           </p>
           
           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina" required>
           </p>
           <p>
             <label for="link">Link</label>
             <input type="text" name="link" id="link" required>
           </p> 

           <p>
                <label for="Slika">Slika:</label>
                <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
             </p>';

               $sql = "SELECT IDMB,Naziv FROM maticne";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDMB" value="' . $row["IDMB"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo'

           <br><br><br>
           <input type="submit" value="Izmeni Maticnu">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>