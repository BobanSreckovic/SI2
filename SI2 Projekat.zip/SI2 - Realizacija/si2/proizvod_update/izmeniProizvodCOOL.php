<?php
session_start();
$x="Admin";
if ($_SESSION["Permisija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni Kuler</title>
</head>

<body>
     <center> 
       <form action="izmeniCOOL.php" method="post" enctype="multipart/form-data">';


              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "si2";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'

           <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv" required>
     </p>

<p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac" required>
     </p>

     <p>
             <label for="cena_nabavna">Nabavna cena</label>
             <input type="text" name="cena_nabavna" id="cena_nabavna" required>
           </p>

           <p>
             <label for="cena_prodajna">Prodajna cena</label>
             <input type="text" name="cena_prodajna" id="cena_prodajna" required>
           </p>

<p>
      <label for="kompatibilnost">Kompatibilnost</label>
      <input type="text" name="kompatibilnost" id="kompatibilnost" required>
     </p>


           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina" required>
           </p>

           <p>
             <label for="link">Link</label>
             <input type="text" name="link" id="link" required>
           </p>

           <p>
                <label for="Slika">Slika:</label>
                <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
             </p>';



               $sql = "SELECT IDCOOL,Naziv FROM hladnjaci";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDCOOL" value="' . $row["IDCOOL"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo '

           <br><br><br>
           <input type="submit" value="Izmeni Kuler">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>