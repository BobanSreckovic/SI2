<?php
session_start();
$x="Admin";
if ($_SESSION["Permisija"] == $x) {echo '<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="/projekat/slike/computer.png">
  <meta charset="UTF-8">
  <title>Izmeni CPU</title>
</head>

<body>
     <center> 
       <form action="izmeniCPU.php" method="post" enctype="multipart/form-data">';


              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "si2";

              $conn = new mysqli($servername, $username, $password, $dbname);
              // Check connection
              if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                 } 

              echo '<a href="/si2/cp/control_panel.php">Nazad na CP</a>';
              echo '<br>';
              echo '<a href="izmeniPro.php">Nazad na stranicu za izmenu proizvoda</a>';
              echo '<br>';
              echo '<br>';
echo'


 <p>
      <label for="nazivKomp">Naziv</label>
      <input type="text" name="naziv" id="naziv" required>
     </p>

      <p>
      <label for="proizvodjac">Proizvodjac</label>
      <input type="text" name="proizvodjac" id="proizvodjac" required>
     </p>

      <p>
             <label for="cena_nabavna">Nabavna cena</label>
             <input type="text" name="cena_nabavna" id="cena_nabavna" required>
           </p>

           <p>
             <label for="cena_prodajna">Prodajna cena</label>
             <input type="text" name="cena_prodajna" id="cena_prodajna" required>
           </p>

     <p>
      <label for="slot">Slot</label>
      <select id="slot" name="slot" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="FM2+">FM2+</option>
        <option value="AM3+">AM3+</option>
        <option value="AM4">AM4</option>
        <option value="TR4">TR4</option>
        <option value="1150">1150</option>
        <option value="1151">1151</option>
        <option value="2066">2066</option>
      </select>
     </p>
    
     <p>
      <label for="takt">Takt</label>
      <select id="takt" name="takt" required>
        <option selected disabled hidden>&nbsp;</option>
        <option value="3.0GHz"> 3.0GHz </option>
        <option value="3.1GHz"> 3.1GHz </option>
        <option value="3.2GHz"> 3.2GHz </option>
        <option value="3.3GHz"> 3.3GHz </option>
        <option value="3.5GHz"> 3.5GHz </option>
        <option value="3.6GHz"> 3.6GHz </option>
        <option value="3.7GHz"> 3.7GHz </option>
        <option value="3.8GHz"> 3.8GHz </option>
        <option value="4.0GHz"> 4.0GHz </option>
        <option value="4.2GHz"> 4.2GHz </option>
      </select>
     </p>
           <p>
            <label for="kolicina">Kolicina</label>
            <input type="text" name="kolicina" id="kolicina" required>
           </p>

<p>
             <label for="link">Link</label>
             <input type="text" name="link" id="link" required>
           </p> 

           <p>
                <label for="Slika">Slika:</label>
                <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
             </p>';


               $sql = "SELECT IDCPU,Naziv FROM procesori";

               $result = $conn->query($sql);

               if ($result->num_rows > 0) {
                   while($row = $result->fetch_assoc()) {
                	   echo '<br>';
                     echo "Naziv: " . $row["Naziv"] . "&nbsp;  &nbsp;  &nbsp;";
                     echo '<input type="radio" name="IDCPU" value="' . $row["IDCPU"] . '. "&nbsp;  &nbsp;  &nbsp;" required>';
                 }
                  } else {
                     echo "Nema proizvoda";
               }
echo'

           <br><br><br>
           <input type="submit" value="Izmeni CPU">
        </form>
     </center>
 </body>
</html>';}else{header('Location: index.php');}
?>