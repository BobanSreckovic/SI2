<?php
 session_start();
 $x="Admin";
 $y="Komercijalista";
 $z="Radnik";

 if ($_SESSION["Permisija"] == $x) {
 	$_SESSION['cart']=array();
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>CP - Vlasnik & Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br><br><br>
			<b><h2>Vlasnik & Admin</h2></b>
			<form action="/si2/proizvod_add/dodajPro.php">
			<button class="button" style="vertical-align:middle">
			<span>Dodaj novi proizvod</span></button></form>
			
			<form action="/si2/proizvod_remove/ukloniPro.php">
			<button class="button" style="vertical-align:middle">
			<span>Ukloni vec postojeci proizvod</span></button></form>
			
			<form action="/si2/proizvod_update/izmeniPro.php">
			<button class="button" style="vertical-align:middle">
			<span>Izmeni specifikacije proizvoda </span></button></form>
			
			<form action="/si2/promena_cena/izmeniCenuPro.php">
			<button class="button" style="vertical-align:middle">
			<span>Promena cene proizvoda </span></button></form>


			<br><br><br>
			<b><h2>Komercijalista</h2></b>
			<form action="/si2/lista_narucenih/naruceni.php">
			<button class="button" style="vertical-align:middle">
			<span>Lista narucenih proizvoda</span></button></form>
			
			<form action="/si2/nabavka_dobavljaci/nabavi.php">
			<button class="button" style="vertical-align:middle">
			<span>Nabavka (dobavljaci)</span></button></form>
			
			<form action="/si2/prijem_robe/prijem.php">
			<button class="button" style="vertical-align:middle">
			<span>Prijem robe</span></button></form>
			
			<form action="/si2/fakture/fakture.php">
			<button class="button" style="vertical-align:middle">
			<span>Fakture</span></button></form>

			<form action="/si2/promena_cena_zbog_nabavne/promenaCZN.php">
			<button class="button" style="vertical-align:middle">
			<span>Promena cena (zbog nabavne)</span></button></form>


			<br><br><br>
			<b><h2>Radnik</h2></b>
			<form action="/si2/prodaja/ListaSvihProizvoda.php">
			<button class="button" style="vertical-align:middle">
			<span>Prodaja proizvoda</span></button></form>
			
			<form action="/si2/proizvod_pretraga/pretraga.php">
			<button class="button" style="vertical-align:middle">
			<span>Pretraga proizvoda</span></button></form>
			
			<form action="/si2/proizvod_zamena/zamena.php">
			<button class="button" style="vertical-align:middle">
			<span>Zamena proizvoda</span></button></form>

			<br><br><br>
			<b><h2>Automatizovane funkcije</h2></b>
			<form action="/si2/automatizovane/popust/pregledPro.php">
			<button class="button" style="vertical-align:middle">
			<span>Nepromenjene zalihe</span></button></form>
			
			<form action="/si2/automatizovane/slaba/pregledPro.php"">
			<button class="button" style="vertical-align:middle">
			<span>Slaba prodaja</span></button></form>
			
			<form action="/si2/automatizovane/sve/sve.php">
			<button class="button" style="vertical-align:middle">
			<span>Celokupni asortiman</span></button></form>

			<br><br><br>
			<b><h2>Help - Pomoc za koriscenje aplikacije</h2></b>
			<form action="/si2/help/help.php">
			<button class="button" style="vertical-align:middle">
			<span>Help - Pomoc</span></button></form>


			<br><br><br>
			<a href="//localhost/si2/index.php">Odjava sa sistema</a>
			<br><br><br>

	    </center>
</body>
</html>';
}elseif ($_SESSION["Permisija"] == $y) {
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>CP - Komercijalista</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body><center>
<br><br><br>
			<b><h2>Komercijalista</h2></b>
			<form action="/si2/lista_narucenih/naruceni.php">
			<button class="button" style="vertical-align:middle">
			<span>Lista narucenih proizvoda</span></button></form>
			
			<form action="/si2/nabavka_dobavljaci/nabavi.php">
			<button class="button" style="vertical-align:middle">
			<span>Nabavka (dobavljaci)</span></button></form>
			
			<form action="/si2/prijem_robe/prijem.php">
			<button class="button" style="vertical-align:middle">
			<span>Prijem robe</span></button></form>
			
			<form action="/si2/fakture/fakture.php">
			<button class="button" style="vertical-align:middle">
			<span>Fakture</span></button></form>

			<form action="/si2/promena_cena_zbog_nabavne/promenaCZN.php">
			<button class="button" style="vertical-align:middle">
			<span>Promena cena (zbog nabavne)</span></button></form>

			<br><br><br>
			<b><h2>Help - Pomoc za koriscenje aplikacije</h2></b>
			<form action="/si2/help/help.php">
			<button class="button" style="vertical-align:middle">
			<span>Help - Pomoc</span></button></form>


			<br><br><br>
			<a href="//localhost/si2/index.php">Odjava sa sistema</a>
			<br><br><br>

	    </center>
</body>
</html>';
}elseif ($_SESSION["Permisija"] == $z) {
	$_SESSION['cart']=array();
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>CP - Radnik</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center><br><br><br>
						<b><h2>Radnik</h2></b>
			<form action="/si2/prodaja/ListaSvihProizvoda.php">
			<button class="button" style="vertical-align:middle">
			<span>Prodaja proizvoda</span></button></form>
			
			<form action="/si2/proizvod_pretraga/pretraga.php">
			<button class="button" style="vertical-align:middle">
			<span>Pretraga proizvoda</span></button></form>
			
			<form action="/si2/proizvod_zamena/zamena.php">
			<button class="button" style="vertical-align:middle">
			<span>Zamena proizvoda</span></button></form>

			<br><br><br>
			<b><h2>Help - Pomoc za koriscenje aplikacije</h2></b>
			<form action="/si2/help/help.php">
			<button class="button" style="vertical-align:middle">
			<span>Help - Pomoc</span></button></form>
			
			<br><br><br>
			<a href="//localhost/si2/index.php">Odjava sa sistema</a>
			<br><br><br>
	    </center>
</body>
</html>';
}
else {
	echo '<center>';
	echo '<br><b>';
	echo 'Molimo Vas da prvo idete na <a href="//localhost/si2/login/login.php">Login stranicu</a> i tamo unesete validne pristupne parametre!';
	echo '<br>';

	echo '</b>';
	echo '</center>';
}
?>