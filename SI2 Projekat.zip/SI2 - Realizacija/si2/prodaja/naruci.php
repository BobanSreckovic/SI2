<?php

session_start();

$tabela = $_GET['table'];

$idProizvoda=$_GET['idT'];

$Naziv = $_GET['naziv'];

$Naruceno = 0;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn= new mysqli($servername, $username,$password, $dbname);

if($conn == false){
	die("ERROR: Could not connect! ".mysql_connect_error());
}

echo'<center><a href="/si2/cp/control_panel.php">Nazad na CP</a></center><br><br>';

$sql1 = "INSERT INTO narudzbina_radnik (Tabela, id, Naziv, Naruceno) VALUES
            ('$tabela', '$idProizvoda', '$Naziv', '$Naruceno')";
//$result1 = $conn->query($sql1)->fetch_object();
$result1 = $conn->query($sql1);

$sql = "SELECT * FROM narudzbina_radnik";
$result = $conn->query($sql)->fetch_object();
$result = $conn->query($sql);

echo '<center>
    

<table border="1">
 <tr>
   <th>Proizvod</th>
   <th>Kolicina</th>
   <th>Cena</th>
   
   
   
 </tr>';

if ($result->num_rows > 0) {

     while($row = $result->fetch_assoc()) {

     	

 echo "<tr>";
    


    echo "<td>"; 
    
    echo $row['Tabela'] ;
    
    echo "<th>"; echo $row['id']; echo "</th>";
    echo "<th>"; echo $row['Naziv']; echo "</th>";
   
  
    
    
    echo "</td>";
}
}

?>