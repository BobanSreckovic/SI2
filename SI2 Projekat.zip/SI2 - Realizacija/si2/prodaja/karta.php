<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn= new mysqli($servername, $username,$password, $dbname);

if($conn == false){
	die("ERROR: Could not connect! ".mysql_connect_error());
}


$table = $_POST['table'];
$id = $_POST['id'];
$idTabele=$_POST['idVr'];



$sql1 = "SELECT * FROM $table WHERE $id=$idTabele";
$result1 = $conn->query($sql1)->fetch_object();

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {

     while($row = $result1->fetch_assoc()) {
     


     


      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo "<center>";
  	  	echo '<img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'"/><br><br>';
      

    foreach($row as $key => $var)
{

   if($key !== $idTabele AND $key !== "Slika"){
    echo $key . ' : ' . $var . '<br />';

}

}


      	if($row['Kolicina'] !=0){

echo '<form method="post" action="DodajUKorpu.php" name="forma">

		<center>
      	<select name="narucena_kolicina">
      	

      	<option value="0">0</option>
      	<option value="1">1</option>
      	<option value="2">2</option>
      	<option value="3">3</option>
      	<option value="4">4</option>
      	<option value="5">5</option>
      	<option value="6">6</option>
      	<option value="7">7</option>
      	<option value="8">8</option>
      	<option value="9">9</option>
      	<option value="10">10</option>
		
		</select> </center>
<input type = "hidden" name="table" value="'. $table.'"><br>
<input type = "hidden" name="idVr" value="'. $idTabele.'"><br>
<input type = "hidden" name="idT" value="'. $id.'"><br>
<input type = "hidden" name="naziv" value="'. $row["Naziv"].'"><br>
<input type = "hidden" name="cena" value="'. $row["Cena_prodajna"].'"><br>


<button style="position: absolute; right: 10%; bottom: 5%;"> Dodaj u korpu </button>
</form>';

}

if($row['Kolicina'] ==0){
echo '<form method="get" action="naruci.php" >
<input type = "hidden" name="table" value="'. $table.'"><br>
<input type = "hidden" name="idT" value="'. $id.'"><br>
<input type = "hidden" name="naziv" value="'. $row["Naziv"].'"><br>
<button style="position: absolute; right: 10%; bottom: 5%;"> Naruci proizvod </button>
</form>';
}


      }
  }




echo '<form method="post" action="ListaSvihProizvoda.php">
    

<button type="submit" style="position: absolute; left: 10%; bottom: 5%;"> Nazad na kupovinu </button>
</form>';








?>




