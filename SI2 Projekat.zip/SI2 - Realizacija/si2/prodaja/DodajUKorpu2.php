
<!DOCTYPE html>
<html>

<body>

	<center>
    

<table border="1">
 <tr>
   <th>Proizvod</th>
   <th>Kolicina</th>
   <th>Cena</th>
   <th>Ukupna Cena</th>
   
   
 </tr>

<?php


session_start();
$x = "Radnik";

$obrisi = $_POST['ime'];
//echo $obrisi;

//print_r($_SESSION['cart']);
$ak = array_search($obrisi, $_SESSION['cart']);
unset($_SESSION['cart'][$ak]);
$_SESSION['cart'] = array_values($_SESSION['cart']);
//print_r($_SESSION['cart']);


if(isset($_SESSION['cart'])){
 for($i=0;$i<count($_SESSION['cart']);$i++){



    echo "<tr>";
    


    echo "<td>"; 
    
    echo $_SESSION['cart'][$i]["naziv"] ;
    
    echo "<th>"; echo $_SESSION['cart'][$i]["broj"]; echo "</th>";
    echo "<th>"; echo $_SESSION['cart'][$i]["cena"]; echo "</th>";
    echo "<th>"; echo $_SESSION['cart'][$i]["uCena"]; echo "</th>";
  
    
    
    echo "</td>";


 }
}



if(count($_SESSION['cart'])>0){

  echo '<form method="post" action="BrisanjeProizvoda.php">
    

<button type="submit" style="position: absolute; left: 10%; bottom: 5%;"> Obrisi jos proizvoda </button>
</form>';





echo '<form method="post" action="StampanjeRacuna.php">
    

<button type="submit" style="position: absolute; right: 10%; bottom: 5%;"> Racun! </button>
</form>';


}
else{
  
  echo '<form method="post" action="ListaSvihProizvoda.php">
    

<button type="submit" style="position: absolute; left: 10%; bottom: 5%;"> Nazad na prodaju proizvoda </button>
</form>';
}


?>
</body>
</html>

