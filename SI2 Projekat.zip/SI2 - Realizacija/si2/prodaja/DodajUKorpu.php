<!DOCTYPE html>
<html>

<body>

<?php


session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn= new mysqli($servername, $username,$password, $dbname);

if($conn == false){
	die("ERROR: Could not connect! ".mysql_connect_error());
}

$table = $_POST['table'];
$id = $_POST['idVr'];
$idTabele=$_POST['idT'];
$Broj=$_POST['narucena_kolicina'];
$Naziv = $_POST['naziv'];
$Cena = $_POST['cena'];

$ukupnaCena = $Cena*$Broj;



//array_push($_SESSION['cart'], $table, $id, $idTabele, $Naziv, $Broj);
array_push($_SESSION['cart'], 
    array("table" => $table, "id" => $id, "idTab" => $idTabele, "naziv" => $Naziv, "broj" => $Broj, "cena" => $Cena, "uCena" => $ukupnaCena));


   
$c= count($_SESSION['cart']);

?>
<center>
    

<table border="1">
 <tr>
   <th>Proizvod</th>
   <th>Kolicina</th>
   <th>Cena</th>
   <th>Ukupna Cena</th>
   
 </tr>
<?php
 for($i=0;$i<$c;$i++){
    if($ukupnaCena>0){
    echo "<tr>";
    echo "<td>"; 
    echo $_SESSION['cart'][$i]["naziv"] ;
    echo "<th>"; echo $_SESSION['cart'][$i]["broj"]; echo "</th>";
    echo "<th>"; echo $_SESSION['cart'][$i]["cena"]; echo "</th>";
    echo "<th>"; echo $_SESSION['cart'][$i]["uCena"]; echo "</th>";
    echo "</td>";}

 }
 
   
   echo'
 </tr>
</table> 
<br><br><br><br>';


echo '<form method="post" action="ListaSvihProizvoda.php">
    

<button type="submit" style="position: absolute; left: 10%; bottom: 5%;"> Nazad na kupovinu </button>
</form>';


echo '
<center>
<form method="post" action="BrisanjeProizvoda.php">
    

<button type="submit" style="position: absolute; bottom: 5%;"> Obrisite proizvod iz liste </button>
</form>';

echo '<form method="post" action="StampanjeRacuna.php">
    

<button type="submit" style="position: absolute; right: 10%; bottom: 5%;"> Racun! </button>
</form>';

?>

 
   
 

    

</body>
</html>