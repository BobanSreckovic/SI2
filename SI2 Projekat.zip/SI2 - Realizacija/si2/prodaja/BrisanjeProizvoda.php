<!DOCTYPE html>
<html>

<body>

	<?php

session_start();


echo '
<center>
<form name="forma" method="post" action="DodajUKorpu2.php">
<select name="ime" >';

for ($i=0;$i<count($_SESSION['cart']);$i++) {
	
	
	//$a =$_SESSION['cart'][$i];
	//$b = $_SESSION['cart'][$i]["naziv"];
	//echo'<option value=" ' .$_SESSION['cart'][$i] .'"> '.$_SESSION['cart'][$i]["naziv"]. '</option>';
	//echo'<option value=" ' .$_SESSION['cart'][$i].'"> '.$_SESSION['cart'][$i]["naziv"]. '</option>';
	echo'<option value=" ' .$i.'"> '.$_SESSION['cart'][$i]["naziv"]. '</option>';

}

 echo'
</select>
<center>
<button> Obrisi! </button>
    </form>

</center>
 

';








?>
</body>
</html>


