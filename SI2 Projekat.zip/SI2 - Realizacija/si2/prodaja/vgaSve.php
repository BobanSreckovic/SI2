<!DOCTYPE html>
<html>
<head>

</head>

<body>

<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

$a = "vga";

$sql1 = "SELECT * FROM vga";
$result1 = $conn->query($sql1)->fetch_object();
?> 

  
 <?php 
   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {

     while($row = $result1->fetch_assoc()) {

      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';

echo '<center>';

	  //echo '<img img height="150" width="150" '. $row['Slika'] .' /><br>';
	  //echo '<img height="150" width="150" src="data:image/jpeg;base64,'.base64_encode( $row['Slika'] ).'"/><br><b';

echo' <a>
    <form action="karta.php" method="post" id="form1">
   		<input type = "hidden" name="table" value="vga"><br>
   		<input type = "hidden" name="idVr" value="IDVGA"><br>
  		<input type="hidden" name="id" value="' .$row['IDVGA'].'"><br>
  		<input type="image" type="submit" img height="150" width="150" src="../proizvod_add/'.$row['Slika'].'" foem="form1" value="posalji">
	</form>
	</a>';

	 

      echo "Naziv: <b>". $row["Naziv"]."</b><br>";

      

      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

      


     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font><br>';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font><br>';
        }

        $b = $row['IDVGA'];
      

      echo'<center>

     
	

     	
     </center>';
 }}
 //<button type="submit" form="form1" value="posalji">Vise informacija</button> 
?>


 <br><br>


 <center><div id="jao1">  <a href="/si2/prodaja/ListaSvihProizvoda.php">Nazad na sve proizvode</a></div></center>

 </center>
