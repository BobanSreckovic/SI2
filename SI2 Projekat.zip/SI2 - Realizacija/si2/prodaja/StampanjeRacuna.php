<?php

session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn= new mysqli($servername, $username,$password, $dbname);

if($conn == false){
	die("ERROR: Could not connect! ".mysql_connect_error());
}


require "fpdf181/fpdf.php";
$sesija = $_SESSION['cart'];


//$brojRacuna = date(gettimeofday(true), time(true));
$brojRacuna = time();
$datum_prodaje = date("Y-m-d");

class myPDF extends FPDF
{

	function header(){
		$this->SetFont('Arial','B',14);
		$this->Cell(276, 5, 'RACUN', 0, 0, 'C');
		$this->Ln();
		$this->SetFont('Times','',14);
		//$date = date('m/d/Y h:i:s a', time());
		$this->Cell(20, 10,'Broj racuna:', 0, 0, 'C');
		$this->Cell(70, 10,time(), 0, 0, 'C');
		
		//$this->Cell(70, 10,gettimeofday(true), 0, 0, 'C');
		$this->Ln();
		$this->SetFont('Times','',14);
		

		$this->Cell(20, 10,'Datum:', 0, 0, 'C');
		$this->Cell(70, 10,date("d/m/Y"), 0, 0, 'C');
		$this->Ln(20);

		
		}

	function footer(){
			$this->SetY(-15);
			$this->SetFont('Arial','',8);
			

	}
	
	function headerTable()
	{
		$this->SetFont('Times','B',12);
		$this->Cell(20,10,' ',1,0,'');
		$this->Cell(100,10,'Naziv proizvoda',1,0,'C');
		$this->Cell(30,10,'Kolicina',1,0,'C');
		$this->Cell(60,10,'Cena',1,0,'C');
		$this->Cell(60,10,'Ukupna cena',1,0,'C');
		$this->Ln();
	}

	

	function viewTable($sesija){

		$this->SetFont('Times', '', 12);

		
		for($i=0;$i<count($_SESSION['cart']);$i++){
			$this->Cell(20,10,$i + 1,1,0,'L');
			$this->Cell(100,10,$_SESSION['cart'][$i]["naziv"],1,0,'L');
			$this->Cell(30,10,$_SESSION['cart'][$i]["broj"],1,0,'L');
			$this->Cell(60,10,$_SESSION['cart'][$i]["cena"],1,0,'L');
			$this->Cell(60,10,$_SESSION['cart'][$i]["uCena"],1,0,'L');
			$this->Ln();
			
		}

		$Ukupna_cena = 0;
			for ($i=0; $i < count($_SESSION['cart']); $i++) { 
				$Ukupna_cena += $_SESSION['cart'][$i]["uCena"];
			}
			$this->Cell(210, 10, "", 0, 0, "L");
			$this->Cell(60,10,$Ukupna_cena,1,0,'L');
			$this->Ln();
		

	}
}


$pdf = new myPDF();
$pdf ->AddPage('L','A4',0);

$pdf->headerTable();
$pdf->viewTable($sesija);




//$brojRacuna = date(gettimeofday(true), time(true));
$filename="Racun_" . $brojRacuna . ".pdf";

//Output the document


$dir = "\D:\wamp\www\si2\prodaja\ ".$filename. "\ "; // full path like C:/xampp/htdocs/file/file/
//$pdf->Output($dir.$filename,'F');

$pdf->Output('F','Racuni/' .$filename.''); 
$pdf->Output();

/*
if( $pdf->Output('F','Racuni/' .$filename.'') ) { redirect($_SERVER["DOCUMENT_ROOT"].'/si2/cp/control_panel.php','refresh'); exit; }
*/

for($i=0;$i<count($_SESSION['cart']);$i++){

	$tabela = $_SESSION['cart'][$i]['table'];
	$broj = $_SESSION['cart'][$i]['broj'];
	$idVrednost=$_SESSION['cart'][$i]['idTab'];
	$idTabele = $_SESSION['cart'][$i]['id'];
	

	$sql1 = "UPDATE $tabela SET Kolicina=Kolicina-$broj, Kolicina_prodato = Kolicina_prodato +$broj, Datum = '$datum_prodaje', Brojac = 0 WHERE $idTabele=$idVrednost";
	//$result1 = $conn->query($sql1)->fetch_object();
	$result1 = $conn->query($sql1);

   
   
}

	unset($_SESSION['cart']);




	//sleep(10); 
	//$pdf->Output();
	//sleep(10);
	//header("Location:/si2/cp/control_panel.php");

	




?>