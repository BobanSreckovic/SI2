<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "si2";

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
     } 

 echo'<center><a href="pregledPro.php">Nazad</a><br><br></center>';

 $IDPWR = mysqli_real_escape_string($conn, $_REQUEST['IDPWR']);
 $popust;

 $sql = "SELECT Brojac FROM napajanja WHERE IDPWR = '$IDPWR'";

$result = $conn->query($sql)->fetch_object();
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
 if($row["Brojac"] < 3){
 	$popust = 0.05;
 }else{
 	$popust = 0;
 }}}

$sql1 = "UPDATE napajanja SET Cena_prodajna = Cena_prodajna - (Cena_prodajna*'$popust'), Brojac = Brojac + 1 WHERE IDPWR = '$IDPWR'";

$result1 = $conn->query($sql1);

 $conn->close();
?>