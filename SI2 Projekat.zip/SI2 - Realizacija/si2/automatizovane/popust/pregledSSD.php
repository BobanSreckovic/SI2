<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Nepromenjene zalihe duze od mesec dana</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
<br>
<a href="/si2/automatizovane/popust/pregledPro.php">Nazad na pregled slabo prodatih proizvoda</a>
         <br><br>
        </center>
         <form action="mesecSSD.php" method="post"><center>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>
<?php
$sql1 = "SELECT IDSSD,Naziv,Cena_prodajna FROM ssd WHERE Datum < DATE(NOW() - INTERVAL 30 DAY) AND Brojac < 3";
$result1 = $conn->query($sql1)->fetch_object();


?> 

 <br>

 <div class="prikazKomponenti"><p>
 <?php 

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br>";
      echo 'Selektuj: <input type="radio" name="IDSSD" value="' . $row["IDSSD"] . '. "&nbsp;  &nbsp;  &nbsp;" required></center>
      </td>';
      echo '</center></table></tr>';

     
      }}
 ?>   

 <br><br><br>
<input type="submit" value="Promeni">
   </form>
 </p></div>

 

 </div></center>
    
</body>
</html> 