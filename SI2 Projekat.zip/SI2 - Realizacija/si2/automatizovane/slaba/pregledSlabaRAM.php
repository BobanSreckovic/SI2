<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Slaba prodaja - RAM</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
       <a href="pregledPro.php">Nazad na slabu prodaju proizvoda</a></center>
         
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
 } 

?>
<?php
$sql1 = "SELECT Naziv,Kolicina,Kolicina_prodato,Datum FROM ram WHERE Kolicina_prodato < 0.5 * (Kolicina + Kolicina_prodato)";
$result1 = $conn->query($sql1)->fetch_object();


?> 

 <br>

 <div class="prikazKomponenti"><p>
 <?php 

   $result1 = $conn->query($sql1);

   if ($result1->num_rows > 0) {
     while($row = $result1->fetch_assoc()) {
      $x = $row["Kolicina"] + $row["Kolicina_prodato"];
      echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Ukupni lager: " . "<b>". $x ."</b>". "<br>";
      echo "Ukupno prodatih: " . "<b>". $row["Kolicina_prodato"]."</b>". "<br>";
      echo "Kolicina na stanju: " . "<b>". $row["Kolicina"]."</b>". "<br>";
      echo "Datum poslednje prodaje: " . "<b>". $row["Datum"]."</b>". "<br>";
      echo '</center>
      </td>';
      echo '</center></table></tr>';

     
      }}
 ?>   

 <br><br><br>
 </p></div>

 

 </div></center>
    
</body>
</html> 