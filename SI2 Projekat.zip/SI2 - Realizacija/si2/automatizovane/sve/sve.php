<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn === false){
  die("ERROR: Could not connect. " . mysqli_connect_error());
 }


$sql1 = "SELECT * FROM dvdrom";
$sql2 = "SELECT * FROM hdd";
$sql3 = "SELECT * FROM hladnjaci";
$sql4 = "SELECT * FROM kucista";
$sql5 = "SELECT * FROM maticne";
$sql6 = "SELECT * FROM napajanja";
$sql7 = "SELECT * FROM procesori";
$sql8 = "SELECT * FROM ram";
$sql9 = "SELECT * FROM ssd";
$sql10 = "SELECT * FROM vga";


$result1 = $conn->query($sql1)->fetch_object();
$result1 = $conn->query($sql1);

$result2 = $conn->query($sql2)->fetch_object();
$result2 = $conn->query($sql2);

$result3 = $conn->query($sql3)->fetch_object();
$result3 = $conn->query($sql3);

$result4 = $conn->query($sql4)->fetch_object();
$result4 = $conn->query($sql4);

$result5 = $conn->query($sql5)->fetch_object();
$result5 = $conn->query($sql5);

$result6 = $conn->query($sql6)->fetch_object();
$result6 = $conn->query($sql6);

$result7 = $conn->query($sql7)->fetch_object();
$result7 = $conn->query($sql7);

$result8 = $conn->query($sql8)->fetch_object();
$result8 = $conn->query($sql8);

$result9 = $conn->query($sql9)->fetch_object();
$result9 = $conn->query($sql9);

$result10 = $conn->query($sql10)->fetch_object();
$result10 = $conn->query($sql10);

echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pregled celokupnog asortimana</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br>
         
 <div class="prikazKomponenti"><p>';


if ($result1->num_rows > 0) {
  while($row = $result1->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result2->num_rows > 0) {
  while($row = $result2->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result3->num_rows > 0) {
  while($row = $result3->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result4->num_rows > 0) {
  while($row = $result4->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result5->num_rows > 0) {
  while($row = $result5->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
     echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
     echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result6->num_rows > 0) {
  while($row = $result6->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result7->num_rows > 0) {
  while($row = $result7->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
      echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result8->num_rows > 0) {
  while($row = $result8->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
    echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result9->num_rows > 0) {
  while($row = $result9->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
     echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
    echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}

   if ($result10->num_rows > 0) {
  while($row = $result10->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo '<img img height="150" width="150" src="../../proizvod_add/'.$row['Slika'].'"/><br>';
      echo "Naziv: " . "<b>". $row["Naziv"]."</b>". "<br>";
     echo "Link: " . "<b><a href=\"". $row["Link"] ."\">Click</a></b>". "<br>";
      echo "Cena: " . "<b>". $row["Cena_prodajna"]. " din" . "</b>"."<br></center></td>";
      echo '</center></table></tr>';

     if ($row["Kolicina"] == 0) {
          echo ' <font color="red"><b>Nema na lageru</b></font> ';
        }else{
          echo ' <font color="green"><b>Na stanju</b></font> ';}
   }}
  
    echo '</p></div>';

mysqli_close($conn);
?>


    
</body>
</html> 