<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Izmena proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Kako izmeniti proizvod?</h1>

<p>


Da biste izmenili proizvod potrebno je pristupiti opciji "Izmeni specifikacije proizvoda".<br>
U novom prozoru se nalaze lista tipova proizvoda. Kliknuti na zeljeni tip proizvoda koga zelite da izmenite. <br>
U novom prozoru se u gornjem delu nalaze polja za unos promena za izabrani proizvod dok se u donjem <br> delu nalazi lista proizvoda po nazivima. Potrebno je u toj listi izabrati proizvod, cekirati ga i u gornjem delu upisati njegove <br> nove karakterisike. Pritiskom na dugme "Izmeni (naziv odabranog tipa proizboda)" dobija se poruka da li su <br> karakteristike proizvoda uspesno zamenjene ili ne.














</p>

	
';
?>