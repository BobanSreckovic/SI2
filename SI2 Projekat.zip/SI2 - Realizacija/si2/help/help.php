<?php
 session_start();
 $x="Admin";
 $y="Komercijalista";
 $z="Radnik";

 if ($_SESSION["Permisija"] == $x) {
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Vlasnik & Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="../cp/control_panel.php">Nazad na CP</a><br><br></center>


	<h1>Pomoc pri koriscenje funkcija Vlasnika & Admina</h1>
 <a href="help1.php">Funkcija - Dodaj proizvod</a> <br><br>
  <a href="help2.php">Funkcija - Ukloni proizvod</a> <br><br>
   <a href="help3.php">Funkcija - Izmeni proizvod</a> <br><br>
    <a href="help4.php">Funkcija - Promena cene</a> <br><br>

    <h1>Pomoc pri koriscenje funkcija Komercijaliste</h1>
 <a href="help5.php">Funkcija - Lista narucenih proizvoda</a> <br><br>
  <a href="help6.php">Funkcija - Nabavka proizvoda od dobavljaca</a> <br><br>
   <a href="help7.php">Funkcija - Prijem robe / proizvoda</a> <br><br>
    <a href="help8.php">Funkcija - Fakture</a> <br><br>
    <a href="help9.php">Funkcija - Promena cene proizvoda zbog promene nabavne cene</a> <br><br>

    	<h1>Pomoc pri koriscenje funkcija Radnika</h1>
 <a href="help10.php">Funkcija - Prodaja proizvoda</a> <br><br>
  <a href="help11.php">Funkcija - Pretraga proizvoda</a> <br><br>
   
    <a href="help13.php">Funkcija - Zamena proizvoda</a> <br><br>

    	<h1>Pomoc pri koriscenje automatizovanih funkcija</h1>
 <a href="help14.php">Funkcija - Nepromenjene zalihe</a> <br><br>
  <a href="help15.php">Funkcija - Slaba prodaja</a> <br><br>
   <a href="help16.php">Funkcija - Celokupni asortiman</a> <br><br>

  </center>
</body>
</html>';
}elseif ($_SESSION["Permisija"] == $y) {
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Komercijalista</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body><center>
<center><a href="../cp/control_panel.php">Nazad na CP</a><br><br></center>
<br><br>
			<h1>Pomoc pri koriscenje funkcija Komercijaliste</h1>
 <a href="help5.php">Funkcija - Lista narucenih proizvoda</a> <br><br>
  <a href="help6.php">Funkcija - Nabavka proizvoda od dobavljaca</a> <br><br>
   <a href="help7.php">Funkcija - Prijem robe / proizvoda</a> <br><br>
    <a href="help8.php">Funkcija - Fakture</a> <br><br>
    <a href="help9.php">Funkcija - Promena cene proizvoda zbog promene nabavne cene</a> <br><br>

			</center>
</body>
</html>';
}elseif ($_SESSION["Permisija"] == $z) {
	$_SESSION['cart']=array();
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Radnik</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body><center><a href="../cp/control_panel.php">Nazad na CP</a><br><br></center>
<br>
		<center>
			<h1>Pomoc pri koriscenje funkcija Radnika</h1>
 <a href="help10.php">Funkcija - Prodaja proizvoda</a> <br><br>
  <a href="help11.php">Funkcija - Pretraga proizvoda</a> <br><br>
   
    <a href="help13.php">Funkcija - Zamena proizvoda</a> <br><br>

			 </center>
</body>
</html>';
}
else {
	echo '<center>';
	echo '<br><b>';
	echo 'Molimo Vas da prvo idete na <a href="//localhost/si2/login/login.php">Login stranicu</a> i tamo unesete validne pristupne parametre!';
	echo '<br>';

	echo '</b>';
	echo '</center>';
}
?>