<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Slaba prodaja</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			<center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Lista proizvoda sa sabom prodajom </h1>

<p>


Ukoliko zelite da izlistate proizvode sa slabom prodajom potrebno je pristupiti opciji "Slaba prodaja".<br>
Na prvoj strani je potrebno odabrati tip proizvoda koji zelimo da pretrazimo.<br> Zatim dobijamo listu proizvoda sa slabom prodajom, njihov naziv, kolicine i datum poslednje prodaje.












</p>

	
';
?>