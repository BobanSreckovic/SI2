<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Fakture</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
				 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Listanje faktura?</h1>

<p>

Ukoliko zelite da vidite fakture za pristiglu robu (prijemnice) potrebno je odabrati opciju "Fakture".<br>
U novom prozoru se nalazi lista svih pristiglih i obradjenih fakura.














</p>

	
';
?>