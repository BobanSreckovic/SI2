<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Nabavka proizvoda od dobavljaca</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			  <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Nabavka proizvoda od registrovanih dobavljaca?</h1>

<p>


Za narucivanje odredjenih proizvoda i njegove kolicine od strane registrovanih dobavljaca potrebno je odabrati opciju "Nabavka (dobavljaci)".<br>
U novom prozoru se prvo nalazi opcija za odabir zeljenog dobavljaca, a potom i kolicina <br> proizvoda koji zelite da porucite.
Odmah potom se nalaze proizvodi koji nisu na stanju i koje je radnik porucio. Potrebno je cekirati naziv <br> zeljenog proizvoda i pritiskom na dugme naruci dobijate informaciju da li je proizvod uspesno narucen.














</p>

	
';
?>