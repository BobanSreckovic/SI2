<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Pretraga proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			<center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Pretraga proizvoda</h1>

<p>


Da bi bilo moguce pretraziti neki proizvod sa odredjenim karakteristikama potrebno je pristupiti opciji "Pretraga proizvoda".<br>
Na prvoj strani se nalaze svi tipovi proizvoda tako da je potrebno selektovati zeljeni tip.<br>
Na sledecoj strani u donjem delu se izlistavaju svi proizvodi odabranog tipa, dok se u prvom delu unose karakteristike proizvoda i moguci naziv.<br>
Opcija "Pretraga" trazi proizvod na osnovu unetih karakteristika, dok opcija "Reset" brise unete karakteristike i omogucava ponovni unos.












</p>

	
';
?>