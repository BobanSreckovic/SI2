<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Prodaja proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Prodaja proizvoda</h1>

<p>


Ukoliko korisnik zeli da kupi neki proizvod prodavac mora pristupiti opciji "Prodaja proizvoda".<br>
Na prvoj strani se nalaze svi tipovi proizvoda tako da je potrebno selektovati zeljeni tip.
U sledecem delu se izlistavaju svi <br> proizvodi odabranog tipa sa prikazanom slikom, nazivom, cenom i da li je proizvod na stanju ili ne. Odabirom proizvoda potrebno je kliknuti na sliku.<br>
U novom prozoru se nalazi nas odabrani proizvod, tako da je sada potrebno samo uneti kolicinu i kliknuti na <br> "Dodaj u korpu".
Na kraju potrebno je potvrditi kupovinu i automatski ce biti izdat racun.












</p>

	
';
?>