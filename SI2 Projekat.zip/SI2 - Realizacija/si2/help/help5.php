<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Pregled narucenih proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Pregled narucenih proizvoda</h1>

<p>


Za dobijanje liste narucenih proizvoda potrebno je odabrati opciju "Lista narucenih proizvoda".<br>
U novom prozoru se nalaze naruceni proizvodi od strane radnika.
Proizvodi su podeljeni tako <br> da zelenom bojom mozemo videti proizvode koji su naruceni od strane dobavljaca, a <br> crvenom bojom mozemo videti proizvode koji jos nisu naruceni od strane dobavljaca.














</p>

	
';
?>