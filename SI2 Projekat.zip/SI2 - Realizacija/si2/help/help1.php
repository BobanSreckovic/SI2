<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Dodavanje proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Kako dodati novi proizvod?</h1>

<p>


Da biste dodali novi proizvod potrebno je pristupiti opciji "Dodaj novi proizvod".<br>
U novom prozoru se nalazi lista tipova proizvoda. Kliknuti na zeljeni tip proizvoda. <br>
Zatim je potrebno uneti parametre proizvoda koji zelimo da dodamo i pritiskom na dugme <br>"Dodaj (naziv odabranog tipa)" dobijamo poruku da li je proizvod uspesno dodat ili ne.














</p>

	
';
?>