<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Zamena proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Zamena proizvoda </h1>

<p>


Da bi bilo moguce zameniti neki proizvod za drugi potrebno je pristupiti opciji "Zamena proizvoda".<br>
Na prvoj strani je prvo potrebno da se unese broj racuna proizvoda koji treba da se zameni.<br> Potom se unese tip i naziv proizvoda koji kupac zeli da vrati i odabere se tip i naziv proizvoda koji kupac zeli da uzme.<br> Klikom na dugme "Zameni proizvod" dobijamo informacije da li je uspesno izvrsena zamena ili ne.












</p>

	
';
?>