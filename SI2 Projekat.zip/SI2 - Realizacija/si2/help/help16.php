<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Celokupni asortiman</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Pregled celokupnog asortimana</h1>

<p>


Ukoliko zelite da izlistate sve proizvode koji se prodaju u prodavnici, potrebno je pristupiti opciji "Celokupni asortiman".<br>
Na narednoj strani se nalazi lista svih proizvoda sa njihovim nazivima, linkovima,<br> cenama, slikama i opisima da li je proizvod dostupan ili ne.












</p>

	
';
?>