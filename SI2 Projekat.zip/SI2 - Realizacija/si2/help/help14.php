<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Popust zbog slabe prodaje</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Lista proizvoda cije se stanje duze vreme nije menjalo </h1>

<p>


Ukoliko zelite da izlistate proizvode cije stanje nije menjano duze vreme potrebno je pristupiti opciji "Nepromenjene zalihe".<br>
Na prvoj strani je potrebno odabrati tip proizvoda koji zelimo da pretrazimo.<br> Zatim dobijamo listu proizvoda koji duzi vremenski period nisu prodavani.<br> Cekiranjem proizvoda i pritiskom na dugme "Promeni" moguce <br> je promeniti cenu (zadati odredjeni popust - 5% mesecno, maksimum 15% za period od tri meseca) nekom proizvodu.












</p>

	
';
?>