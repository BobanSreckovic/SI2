<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Uklanjanje proizvoda</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
 <center><a href="help.php">Nazad na Help</a><br><br></center>
 <h1>Uputstvo - Kako ukloniti proizvod?</h1>

<p>


Da biste uklonili proizvod potrebno je pristupiti opciji "Ukloni vec postojeci proizvod".<br>
U novom prozoru se nalaze lista tipova proizvoda. Kliknuti na zeljeni tip proizvoda koga zelite ukoniti. <br>
U novom prozoru se nalazi lista proizvoda odabranog tipa. Potrebno je po nazivu odabrati prozvod koji zelite ukloniti,<br>cekirati taj proizvod i pritiskom na dugme "Obrisi (naziv odabranog tipa proizvoda)" dobijate poruku da li je proizvod uspesno obrisan ili ne.














</p>

	
';
?>