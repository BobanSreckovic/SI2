<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Promena cene</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Promena cene proizvoda?</h1>

<p>

Ukoliko zelite da promenite cenu nekog proizvoda potrebno je odabrati opciju "Promena cene proizvoda".<br>
U novom prozoru se nalaze opcije koje odredjuju nacin promene cene:<br><p>
1. Po proizvodjacu - bira se proizvodjac i unosi se zeljeni popust.<br>
2. Po vrsti proizvoda - bira se tip proizvoda i unosi se zeljeni popust.<br></p>
U oba slicaja unete parametre potvrdjujemo pritiskom na dugme "Promeni cene" i tako dobijamo informaciju <br> da li je promena uspesno uradjena.













</p>

	
';
?>