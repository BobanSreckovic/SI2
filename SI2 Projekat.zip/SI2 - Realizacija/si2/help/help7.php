<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Prijem robe</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Prijem robe?</h1>

<p>

Ukoliko zelite da obalezite proizvode koji su dostavljeni od strane dobavljaca potrebno je odabrati opciju "Prijem robe".<br>
U novom prozoru se nalazi lista narucenih proizvoda od dobavljaca. Potrebno je pronaci u toj listi proizvod koji je stigao od strane dobavljaca, <br> cekirati ga i klikom na "Primi robu" dobijamo informaciju da li je ova operacija uspesno uradjena ili ne.














</p>

	
';
?>