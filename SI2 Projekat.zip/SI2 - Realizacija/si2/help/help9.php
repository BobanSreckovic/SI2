<?php
 
  echo '
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="/si2/slike/computer.png">
	<meta charset="UTF-8">
	<title>Help - Promena nabavne cene</title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
		<center>
			<br>
			 	 <center><a href="help.php">Nazad na Help</a><br><br></center>
<h1>Uputstvo - Promena nabavne cene?</h1>

<p>


Da biste izmenili nabavnu cenu nekog proizvoda potrebno je pristupiti opciji "Promena cene (zbog nabavne)".<br>
U novom prozoru se nalazi lista tipova proizvoda. Kliknuti na zeljeni tip proizvoda kome zelite da promenite nabavnu cenu. <br>
U novom prozoru se u gornjem delu nalaze polje za unos promena nabavne cene odredjenog proizvoda dok se u donjem <br> delu nalazi lista proizvoda po nazivima. Potrebno je u toj listi izabrati proizvod, cekirati ga i u gornjem delu upisati njegovu <br> novu nabavnu cenu. Pritiskom na dugme "Promeni" dobija se poruka da li je <br> nabavna cena uspesno promenjena ili ne.














</p>

	
';
?>