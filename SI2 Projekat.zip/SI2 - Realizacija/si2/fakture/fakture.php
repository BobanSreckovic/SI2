<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "si2";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn === false){
  die("ERROR: Could not connect. " . mysqli_connect_error());
 }


$sql = "SELECT * FROM fakture";



$result1 = $conn->query($sql)->fetch_object();
$result1 = $conn->query($sql);


echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="icon" href="/projekat/slike/computer.png">
        <meta charset="UTF-8">
        <title>Pregled svih primljenih proizvoda od dobavljaca</title>
    </head>

<body>
  <center>
<a href="/si2/cp/control_panel.php">Nazad na CP</a>
         <br><br>
         
 <div class="prikazKomponenti"><p>';


if ($result1->num_rows > 0) {
  while($row = $result1->fetch_assoc()) {
    echo '<center><table><tr>';
      echo '<br>';
      echo '<td>';
      echo "Naziv proizvoda: " . "<b>". $row["Ime"]."</b>". "<br>";
      echo "Dobavio: " . "<b>". $row["Dobavljac"]."</b>". "<br>";
      echo "Pristigla kolicina: " . "<b>". $row["Kolicina"]."</b>". "<br>";

      echo '</center></table></tr>';
    }
   }
  
    echo '</p></div>';

mysqli_close($conn);
?>


    
</body>
</html> 