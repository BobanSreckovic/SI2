<?php 
session_start();
$_SESSION["Permisija"] = "korisnik";
?>

<!DOCTYPE html>
<html lang="en">
<html>
<head>
 <link rel="icon" href="/si2/slike/computer.png">
 <title>Stranica prijave</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
 <center>
 	<br><br><br><br><br>
 	<form action="loginProvera.php" method="post">
 	 <h1>Prijava korisnika</h1>
 	 <div class="inset">
 	 <p>
     <label for="korisnicko">Korisnicko ime</label><input type="text" name="korisnicko">
     </p>
     <p>
     <label for="lozinka">Lozinka</label><input type="password" name="lozinka">
     </p>
     </div>
     <p class="p-container">
     <input type="submit" value="Prijavi se">
     </p>
	</form>
 </center>
</body>
</html>