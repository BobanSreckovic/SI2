<?php 
  session_start();
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "si2";

  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
   } 

  $korisnicko_u = $_POST['korisnicko'];
  $lozinka_u = $_POST['lozinka'];
    
  $sql1 = "SELECT Permisija_Pozicije FROM zaposleni WHERE Korisnicko_ime='$korisnicko_u' AND Lozinka='$lozinka_u'";
  $result1 = $conn->query($sql1);

  if ($result1->num_rows > 0) {
    while ($row = $result1->fetch_assoc()) {
      $x = $row["Permisija_Pozicije"];
    }
  }

  if ($x == 1) {
    $_SESSION["Permisija"] = "Admin";
    header('Location: //localhost/si2/cp/control_panel.php');
  }elseif ($x == 2) {
    $_SESSION["Permisija"] = "Admin";
    header('Location: //localhost/si2/cp/control_panel.php');
  }elseif ($x == 3) {
    $_SESSION["Permisija"] = "Komercijalista";
    header('Location: //localhost/si2/cp/control_panel.php');
  }elseif ($x == 4) {
    $_SESSION["Permisija"] = "Radnik";
    header('Location: //localhost/si2/cp/control_panel.php');
  }else {
    header('Location: //localhost/si2/login/login.php');
  }
?>